/**
1. Obtener los nombres y salarios de los empleados que cobran m�s de 985 euros y
tienen una comisi�n es superior al 5% de su salario.
**/
SELECT nombre, salario FROM empleado WHERE salario > 985 AND comision > (salario * 0.05);

SELECT e.nombre || ' ' || e.ape1 || ' ' || e.ape2, e.salario, e.comision, (e.comision / e.salario) * 100 AS "PORCENTAJE"
    FROM empleado e
    WHERE e.salario > 985 AND e.comision > (e.salario * 0.05);

/**
2. Obtener el c�digo de empleado, c�digo de departamento, nombre y sueldo total 
en pesetas de aquellos empleados cuyo sueldo total (salario m�s comisi�n) supera 
los 1350 euros. Presentarlos ordenados por c�digo de departamento y dentro de 
�stos por orden alfab�tico.
**/
/*
--NVL(expresion, valor): lo que hace es devolver el valor, si la primera expresi�n tiene un valor null.
SELECT e.nombre, NVL(e.salario + e.comision, e.salario) AS "SUELDO TOTAL" FROM empleado e;
--NVL2(expresion, valor1, valor2): si el valor de la expresi�n NO es nulo nos devuelve el primer valor, y si es null el segundo
SELECT e.nombre, NVL2(e.comision, e.salario + e.comision, e.salario) AS "SUELDO TOTAL" FROM empleado e;
*/
SELECT e.codemple, e.coddpto, e.nombre, e.salario,
    NVL(e.comision, 0) AS "COMISION",
    NVL2(e.comision, e.salario + e.comision, e.salario) * 166.386 AS "SUELDO TOTAL ptas"
    FROM empleado e
    WHERE NVL2(e.comision, e.salario + e.comision, e.salario) > 1350
    ORDER BY e.coddpto, e.nombre;

/**
3.	Obtener un listado con los nombres, y apellidos de los empleados y sus a�os
de antig�edad en la empresa, ordenado por a�os de antig�edad siendo los que m�s
a�os llevan los primeros que deban aparecer.
**/
SELECT e.nombre, e.ape1, e.ape2, e.fechaingreso,
    TRUNC(MONTHS_BETWEEN(SYSDATE,e.fechaingreso)/12, 0) AS Antig�edad
    FROM empleado e
    ORDER BY Antig�edad DESC;

/**
4. Obtener el nombre de los empleados que trabajan en un departamento con presupuesto
superior a 50.000 euros pero menor de 60000 euros. Hay que usar predicado cuantificado
**/
SELECT e.nombre, d.coddpto AS "CODIGO DPTO", d.denominacion, d.presupuesto AS "PRESUPUESTO DPTO" FROM empleado e
  JOIN dpto d ON d.coddpto = e.coddpto
  WHERE d.presupuesto = ANY (
    SELECT d.presupuesto FROM dpto d WHERE d.presupuesto > 50000 AND d.presupuesto < 60000)
  ORDER BY e.coddpto;
-- No da ningun resultado debido a que no hay ningun dpto que cumpla con la condici�n
-- SELECT d.presupuesto FROM dpto d ;

/**
5. Obtener en orden alfab�tico los nombres de empleado cuyo salario es inferior
al m�nimo de los empleados del departamento 1.
**/
SELECT e.nombre, e.salario 
    FROM empleado e
    WHERE /* salario < al menor salario de los empleados del dpto 1*/
    e.salario < (
        SELECT MIN(e1.salario) FROM empleado e1 WHERE e1.coddpto = 1);

/**
6. Obtener el nombre de los empleados que trabajan en el departamento del cu�l es
jefe el empleado con c�digo 1.
**/
SELECT e.nombre || ' ' || e.ape1 AS nombre, e.coddpto, d.denominacion, d.codemplejefe
    FROM empleado e
    INNER JOIN dpto d ON e.coddpto = d.coddpto
    WHERE d.codemplejefe = 1; 

/**
7. Obtener los nombres de los empleados cuyo primer apellido empiece por una de
las siguientes letras: p, q, r, s.
**/
SELECT e.nombre, e.ape1 FROM empleado e
  WHERE
    LOWER(e.ape1) LIKE('p%')
    OR LOWER(e.ape1) LIKE('q%')
    OR LOWER(e.ape1) LIKE('r%')
    OR LOWER(e.ape1) LIKE('s%');

/**
8. Obtener los nombres de los empleados que viven en ciudades en las que hay alg�n
centro de trabajo
**/
SELECT nombre, localidad
    FROM empleado
    WHERE UPPER(localidad) = ANY (
        SELECT UPPER(localidad) FROM centro
    );

/**
9. Obtener en orden alfab�tico los salarios y nombres de los empleados cuyo salario
sea superior al 60% del m�ximo salario de la empresa.
**/
SELECT e.nombre, e.salario
    FROM empleado e
    WHERE e.salario > (
        SELECT MAX(e.salario) * 0.6 FROM empleado e);

/**
10.	El nombre y apellidos del empleado que m�s salario cobra
**/
SELECT e.nombre, e.ape1, e.ape2, e.salario
    FROM empleado e
    WHERE e.salario = (
        SELECT MAX(e.salario)FROM empleado e);

/**
11. Obtener las localidades y n�mero de empleados de aquellas en las que viven
m�s de 3 empleados
**/
SELECT localidad, COUNT(codemple) AS num_empleados FROM empleado  
    GROUP BY localidad
    HAVING COUNT(codemple) > 3;

/**
12. Obtener los nombres de todos los centros y los departamentos que se ubican en
cada uno, as� como aquellos centros que no tienen departamentos.
**/
-- Consulta sin modificar la tabla del ejercicio, usando el campo codcentro en vez del nombre
SELECT c.codcentro, d.denominacion AS Departamento FROM centro c
    LEFT OUTER JOIN dpto d ON c.codcentro = d.codcentro
    ORDER BY c.codcentro;

/**
-- NO Exite un campo nombre. Modifico la tabla, para  poder trabajar con los nombres
-- Inserto un centro nuevo que no tiene departamentos, para poder comprobar que,
la consulta, lista tambi�n los centros que no tienen departamentos
**/
-- Modificaci�n de la tabla
ALTER TABLE centro ADD (nombre_centro VARCHAR2(20));
-- Actualizar contenido de los registros existentes
UPDATE centro SET NOMBRE_CENTRO = 'centro1' WHERE codcentro = 1;
UPDATE centro SET NOMBRE_CENTRO = 'centro2' WHERE codcentro = 2;
UPDATE centro SET NOMBRE_CENTRO = 'centro3' WHERE codcentro = 3;
-- Insertar un nuevo registro -centro- que no tiene asignado ningun departamento
INSERT INTO centro (codcentro, direccion, localidad, nombre_centro) VALUES (9,'nueva_dir', 'nueva_loc', 'centro9');
-- Consulta
SELECT c.codcentro, c.nombre_centro, d.denominacion AS Departamentos FROM centro c
    LEFT OUTER JOIN dpto d ON c.codcentro = d.codcentro
    ORDER BY c.nombre_centro;

/**
13.	Obtener el nombre del departamento de m�s alto nivel, es decir, aquel que no
depende de ning�n otro.
**/
SELECT * FROM dpto d WHERE d.coddptodepende IS null;

/**
14.	Obtener el departamento que m�s empleados tiene
**/
--SELECT MAX(COUNT(*)) from empleado group by coddpto;
SELECT d.coddpto, d.denominacion, COUNT(e.codemple) AS num_empleados
    FROM dpto d
    INNER JOIN empleado e ON d.coddpto = e.coddpto
    GROUP BY d.denominacion, d.coddpto
    HAVING COUNT(*) = (
        SELECT MAX(COUNT(*)) from empleado group by coddpto);

--Usando "tabla temporal"
SELECT t.coddpto, t.denominacion, t.num_empleados
    FROM (
        SELECT d.coddpto, d.denominacion, COUNT(*) AS num_empleados
            FROM empleado e, dpto d
            WHERE d.coddpto = e.coddpto
            GROUP BY d.denominacion, d.coddpto
        ) t
    WHERE t.num_empleados = (
        SELECT MAX(t2.num_empleados) FROM  (
            SELECT d.denominacion, COUNT(*) AS num_empleados
                FROM empleado e, dpto d
                WHERE d.coddpto = e.coddpto
                GROUP BY d.denominacion
            ) t2);

/**
15.	Obtener todos los departamentos existentes en la empresa y los empleados (si
los tiene) que pertenecen a �l.
**/
SELECT d.coddpto, d.denominacion, e.nombre || ' ' || e.ape1 AS Empleado
    FROM dpto d
    INNER JOIN empleado e ON d.coddpto = e.coddpto
    ORDER BY d.coddpto;
    
/** Muestra todos los departamentos existentes en la empresa y el numero de empleados
de cada departamente (si los tiene) que pertenecen a �l
**/
SELECT d.coddpto, d.denominacion, COUNT(e.codemple) FROM dpto d
    INNER JOIN empleado e ON d.coddpto = e.coddpto
    GROUP BY d.denominacion, d.coddpto;
    
/**
16.	Obtener un listado ordenado alfab�ticamente donde aparezcan los nombres de 
los empleados y a continuaci�n el literal "tiene comisi�n" si la tiene o "no tiene
comisi�n" si no la tiene.
--NVL2(expresion, valor1, valor2): si el valor de la expresi�n NO es nulo nos devuelve el primer valor, y si es null el segundo
**/
SELECT e.nombre || ' ' || e.ape1 AS Empleado, NVL2(e.comision, 'tiene comision', 'no tiene comision') AS Comision
    FROM empleado e
    ORDER BY e.nombre ASC;
    
/**
17.	Obtener un listado de las localidades en las que hay centros y no vive ning�n
empleado ordenado alfab�ticamente.
**/
SELECT c.localidad FROM centro c
    LEFT OUTER JOIN empleado e ON c.localidad = e.localidad;
    
/**
18.	Obtener a los nombres, apellidos de los empleados que no son jefes de departamento.
**/
SELECT e.codemple, e.nombre, e.ape1 || ' ' || e.ape2 AS apellidos
    FROM empleado e
    WHERE e.codemple NOT IN (
        SELECT d.codemplejefe FROM dpto d
        );
        
/**
19.	Esta cuesti�n punt�a doble. Se desea dar una gratificaci�n por navidades en
funci�n de la antig�edad en la empresa siguiendo estas pautas:
a.	Si lleva entre 1 y 5 a�os, se le dar� 100 euros
b.	Si lleva entre 6 y 10 a�os, se le dar� 50 euros por a�o
c.	Si lleva entre 11 y 20 a�os, se le dar� 70 euros por a�o
d.	Si lleva m�s de 21 a�os, se le dar� 100 euros por a�o
**/
SELECT nombre, FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) AS Antiguedad,
        CASE
        
            -- a.Si lleva entre 1 y 5 a�os, se le dar� 100 euros
            WHEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) BETWEEN 1 AND 5
            THEN 100
            -- b.Si lleva entre 6 y 10 a�os, se le dar� 50 euros por a�o
            WHEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) BETWEEN 6 AND 10
            THEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) * 50
            -- c.Si lleva entre 11 y 20 a�os, se le dar� 70 euros por a�o
            WHEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) BETWEEN 11 AND 20
            THEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) * 70
            -- d.Si lleva m�s de 21 a�os, se le dar� 100 euros por a�o
            WHEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) >= 21
            THEN FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) * 100
            -- Para cualquier otro caso
            ELSE FLOOR(MONTHS_BETWEEN(SYSDATE, fechaingreso)/12) * 0
            
        END AS gratificacion
    FROM empleado
    ORDER BY nombre;